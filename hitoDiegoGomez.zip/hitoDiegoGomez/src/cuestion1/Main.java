package cuestion1;

public class Main {

	public static void main(String[] args) {
		Trabajador t1 = new Trabajador("Diego","Getafe",3500,"tres meses.");
		
		t1.generico();
		

	}

}

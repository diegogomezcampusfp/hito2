package cuestion1;

//Clase trabajador con sus atributos 

public class Trabajador {

	String nombre;
	String ciudad;
	float salarioBruto;
	String contratoTemporal;
	
//Constructor
	
public Trabajador(String Cnombre, String Cciudad, float CsalarioBruto, String CcontratoTemporal) {
	
	nombre = Cnombre;
	ciudad = Cciudad;
	salarioBruto = CsalarioBruto;
	contratoTemporal = CcontratoTemporal;
	
	
	
}

//Getters y setters

public String getNombre() {
	return nombre;
}

public void setNombre(String nombre) {
	this.nombre = nombre;
}

public String getCiudad() {
	return ciudad;
}

public void setCiudad(String ciudad) {
	this.ciudad = ciudad;
}

public float getSalarioBruto() {
	return salarioBruto;
}

public void setSalarioBruto(float salarioBruto) {
	this.salarioBruto = salarioBruto;
}

public String isContratoTemporal() {
	return contratoTemporal;
}

public void setContratoTemporal(String contratoTemporal) {
	this.contratoTemporal = contratoTemporal;
}
	
//Método genérico para mostrar ficha del trabajador

public void generico() {
	System.out.println("Tu nombre es "+nombre+" y vives en "+ciudad+" ,tu salario bruto es "+salarioBruto+" y tu contrato temporal es de "+contratoTemporal);
}
}

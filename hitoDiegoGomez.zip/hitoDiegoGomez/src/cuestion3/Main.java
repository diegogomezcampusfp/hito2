package cuestion3;

public class Main {

	public static void main(String[] args) {
		Nucleo cuerpo[] = new Nucleo[3];

		cuerpo[0] = new Nucleo("Torso","Cintura");
		cuerpo[1] = new Superior("Torso", "Cintura", "Pecho");
		cuerpo[2] = new Inferior("Torso", "Cintura", "Rodillas");
		
		for (Nucleo partes: cuerpo) {
			System.out.println(partes.mostrarPartes());
			System.out.println("");
		}
	}

}

package cuestion3;

public class Superior extends Nucleo {
	private String Pecho;

	public Superior(String pSuperior, String pInferior, String pecho) {
		super(pSuperior, pInferior);
		Pecho = pecho;
	}

	public String getPecho() {
		return Pecho;
	}

	@Override
	public String mostrarPartes() {
		 return "En la parte superior se encuentra el "+Pecho;
	}
	
	

}

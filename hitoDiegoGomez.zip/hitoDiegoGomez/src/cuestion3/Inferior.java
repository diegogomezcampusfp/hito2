package cuestion3;

public class Inferior extends Nucleo {
	private String bajo;

	
	public Inferior(String pSuperior, String pInferior, String Bajo) {
		super(pSuperior, pInferior);
		bajo = Bajo;
	}

	

	public String getBajo() {
		return bajo;
	}

	@Override
	public String mostrarPartes() {
		 return "En la parte inferior se encuentran las "+bajo;
	}
	
	

}

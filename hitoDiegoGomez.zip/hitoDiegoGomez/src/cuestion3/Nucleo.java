package cuestion3;

public class Nucleo {

	protected String PSuperior;
	protected String PInferior;
	
	public Nucleo(String pSuperior, String pInferior) {
		PSuperior = pSuperior;
		PInferior = pInferior;
	}

	public String getPSuperior() {
		return PSuperior;
	}

	public void setPSuperior(String pSuperior) {
		PSuperior = pSuperior;
	}

	public String getPInferior() {
		return PInferior;
	}

	public void setPInferior(String pInferior) {
		PInferior = pInferior;
	}
	
	public String mostrarPartes() {
		return "En la parte superior se encuentra el "+PSuperior+" y en la parte inferior la "+PInferior;
	}
	
}

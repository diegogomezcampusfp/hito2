package cuestion2;

public class Main {

	public static void main(String[] args) {
		Hija h1 = new Hija("Lara",20);
		
		h1.Saludar();
		

	}

}
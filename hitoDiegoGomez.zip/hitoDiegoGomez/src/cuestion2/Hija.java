package cuestion2;
//Este concepto se conoce como heredar, y se aplica utilizando extends. Cuando la clase Hija hereda la clase Padre, hereda sus atributos y m�todos.
public class Hija extends Padre {
//Constructor de la hija (super debido a la herencia).
	public Hija(String Cnombre, int Cedad) {
		super(Cnombre, Cedad);
		
	}
//M�todo saludar de la hija
	public void Saludar() {
		System.out.println("Hola, soy la hija");
	 }
}
